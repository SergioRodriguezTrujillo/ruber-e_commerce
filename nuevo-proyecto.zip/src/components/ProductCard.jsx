"use client"

import { useState } from "react"
import { Heart } from "lucide-react"
import { useCart } from "../context/CartContext"
import { useWishlist } from "../context/WishlistContext"
import "./ProductCard.css"

const ProductCard = ({ product }) => {
  const { addToCart } = useCart()
  const { addToWishlist, isInWishlist, removeFromWishlist } = useWishlist()
  const [selectedColor, setSelectedColor] = useState(product.colors[0])

  const handleToggleWishlist = (e) => {
    e.stopPropagation() // Evitar que el clic se propague a la tarjeta
    if (isInWishlist(product.id)) {
      removeFromWishlist(product.id)
    } else {
      addToWishlist(product)
    }
  }

  const handleAddToCart = (e) => {
    e.stopPropagation() // Evitar que el clic se propague a la tarjeta
    addToCart({
      ...product,
      selectedColor,
      quantity: 1,
    })
  }

  return (
    <div className="product-card">
      {product.discount > 0 && <span className="discount-badge">-{product.discount}%</span>}

      <div className="product-image">
        <img src={product.image || "/placeholder.svg"} alt={product.name} />
      </div>

      <div className="product-title-container">
        <h3 className="product-title">{product.name}</h3>
        <button
          className={`action-btn wishlist-btn ${isInWishlist(product.id) ? "active" : ""}`}
          onClick={handleToggleWishlist}
        >
          <Heart size={16} />
        </button>
      </div>

      <div className="product-price">
        <span className="current-price">${product.price.toFixed(2)}</span>
        {product.originalPrice && <span className="original-price">${product.originalPrice.toFixed(2)}</span>}
      </div>

      <div className="rating">
        {[...Array(5)].map((_, i) => (
          <span key={i} className={`star ${i < product.rating ? "filled" : ""}`}>
            ★
          </span>
        ))}
        <span className="rating-count">({product.reviewCount})</span>
      </div>

      <div className="color-options">
        {product.colors.map((color) => (
          <div
            key={color}
            className={`color-option ${color} ${selectedColor === color ? "selected" : ""}`}
            onClick={(e) => {
              e.stopPropagation() // Evitar que el clic se propague a la tarjeta
              setSelectedColor(color)
            }}
          />
        ))}
      </div>

      <div className="product-buttons">
        <button className="info-btn">Info</button>
        <button className="quote-btn">Solicitar cotización</button>
      </div>

      {/* Add to Cart button that appears on hover */}
      <button className="add-to-cart-btn" onClick={handleAddToCart}>
        Agregar al carrito
      </button>
    </div>
  )
}

export default ProductCard
